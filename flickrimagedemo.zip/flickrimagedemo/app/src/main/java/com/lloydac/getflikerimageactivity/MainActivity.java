package com.lloydac.getflikerimageactivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import com.flickr4java.flickr.Flickr;
import com.flickr4java.flickr.REST;
import com.flickr4java.flickr.photos.Photo;
import com.flickr4java.flickr.photos.PhotoList;
import com.flickr4java.flickr.photos.SearchParameters;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String API_KEY= "d6bb54b16f10f0088c104218c35db20e";
    private static final String API_SECRET= "b32101fc82fec5b1";
    private RecyclerView rvImages;
    private EditText etSearch;
    private Context context;
    private ImageAdapter imageAdapter;
    private ArrayList<String> imageList;
    private CountDownTimer timer;
    private int visibleThreshold = 5;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;
    private int pageNumber=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=MainActivity.this;
        findIds();
        setRecyclerView();
        setListeners();
    }

    private void findIds() {
        rvImages= findViewById(R.id.rv_images);
        etSearch= findViewById(R.id.et_search);
    }

    private void setRecyclerView() {
        imageList=new ArrayList<>();
        imageAdapter = new ImageAdapter(context,imageList);
        rvImages.setLayoutManager(new GridLayoutManager(context,3));
        rvImages.setAdapter(imageAdapter);
    }

    /**
     *  TextChangedListener: is to manage the text inputting to edit text
     *  ScrollListener: is to manage scroll fo recycler view (scroll reaches to bottom or not)
     */
    private void setListeners() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void afterTextChanged(Editable s) {
                if(timer!=null){
                    timer.cancel();
                    timer=null;
                }
                startTimer();
            }
        });

        final LinearLayoutManager linearLayoutManager = (LinearLayoutManager) rvImages.getLayoutManager();
               rvImages.addOnScrollListener(new RecyclerView.OnScrollListener() {
                    @Override
                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                        super.onScrolled(recyclerView, dx, dy);
                        totalItemCount = linearLayoutManager.getItemCount();
                        lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                        if (!loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                            loading = true;
                            pageNumber=pageNumber+1;
                            new LongOperation().execute(etSearch.getText().toString().trim());
                        }
                    }
                });
    }


    /**
     *  CountDownTimer used to manage user rapid inputting text to edit text
     */
    private void startTimer(){
         timer = new CountDownTimer(1000, 1000) {
            public void onTick(long millisUntilFinished) { }
            public void onFinish() {
                imageList.clear();
                pageNumber=1;
                new LongOperation().execute(etSearch.getText().toString().trim());
            }
        }.start();
    }


    /**
     * @Param:-imageText name to the image to search image
     *  AsyncTask used to fetch the image from  'Flickr' server and adding images to the list
     *  and notifying the recycler adapter
     */
    private final class LongOperation extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... imageText) {
            try {
                REST rest = new REST();
                Flickr flickrClient = new Flickr(API_KEY, API_SECRET, rest);
                SearchParameters searchParameters = new SearchParameters();
                searchParameters.setText(imageText[0]);
                PhotoList photos = flickrClient.getPhotosInterface().search(searchParameters,20,pageNumber);
                for(int i=0;i<photos.size();i++){
                    imageList.add(((Photo) photos.get(i)).getSmallUrl());
                }
            } catch (Exception ex) {
                Log.d("Error", ex.getLocalizedMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            loading=false;
            imageAdapter.notifyDataSetChanged();
        }
    }
}
